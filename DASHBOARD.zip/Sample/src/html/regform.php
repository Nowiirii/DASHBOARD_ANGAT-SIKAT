<?php

// Enable error reporting for debugging (optional in development environment)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$host = 'localhost'; 
$dbname = 'angat_sikat_db';  
$username = 'root';  
$password = '';  

// Database connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = trim($_POST['fname']);  
    $lname = trim($_POST['lname']);  
    $email = trim($_POST['email']);  
    $pnumber = trim($_POST['pnumber']);  
    $cyr = trim($_POST['cyr']);  
    $studNo = trim($_POST['studNo']);  
    $pword = $_POST['pword'];  
    $cPassword = $_POST['confirmpassword'];  

    // Basic form validation
    if (empty($fname) || empty($lname) || empty($email) || empty($pnumber) || empty($cyr) || empty($studNo) || empty($pword) || empty($cPassword)) {
        echo "All fields are required!";
        exit();
    }

    // Email format validation
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format!";
        exit();
    }

    // Check if passwords match
    if ($pword !== $cPassword) {
        echo "Passwords do not match!";
        exit();
    }

    // Hash the password before storing
    $hashedPassword = password_hash($pword, PASSWORD_BCRYPT);

    // Prepare the SQL statement to insert data
    $sql = "INSERT INTO regform (fname, lname, email, pnumber, cyr, studNo, pword) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    // Prepare and bind
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);
    }

    $stmt->bind_param("sssssss", $fname, $lname, $email, $pnumber, $cyr, $studNo, $hashedPassword);

    // Execute and check if data is inserted
    if ($stmt->execute()) {
        // Redirect to login page after successful registration
        header("Location: authentication-login.html");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}

// Close the connection
$conn->close();

?>
