function toggleSubMenu(id) {
    const submenu = document.getElementById(id);
    const isVisible = submenu.style.display === "flex";
  
    // Hide all submenus
    document.querySelectorAll('.submenu').forEach(sub => sub.style.display = "none");
  
    // Toggle the clicked submenu
    submenu.style.display = isVisible ? "none" : "flex";
  }
  